package com.example.familymap.ui

import Exchange.Response
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.familymap.R

class PersonActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_person)
    }
}